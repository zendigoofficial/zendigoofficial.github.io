ERRORLIGHT XBOX / GAMESIR G7 PRO INPUT OVERLAY

Files
-----
xbox-controller-errorlight.png   Full 2048 x 2391 sprite sheet
xbox-controller-errorlight.json  Matching Input Overlay configuration

OBS setup
---------
1. Add a new Input Overlay source in OBS.
2. Set Texture to xbox-controller-errorlight.png.
3. Set Config to xbox-controller-errorlight.json.
4. Connect the GameSir G7 Pro to the PC in XInput mode.
5. Enable the gamepad hook in Input Overlay's configuration.
6. Click Reload gamepads, then select the GameSir/XInput controller under Gamepad ID.

The PNG and JSON are a matched pair. Do not resize or crop the PNG; the JSON
uses exact pixel coordinates to pull the body, buttons, triggers, sticks, and
D-pad states from the sprite sheet.

Colors sampled from the supplied Errorlight overlay:
Top green:  #17D785
Bottom cyan: #00C9D4

Preset base: univrsal/input-overlay Xbox controller preset by Saikel Orado Liu,
released under CC0. Recolor and packaging prepared for Errorlight Studios.
